# Responsive Fashion Landing Page
## [Watch it on youtube](https://youtu.be/CbQFhLQgLGs)
### Responsive Fashion Landing Page

- Responsive Fashion Landing Page Using HTML CSS & JavaScript.
- Contains animations made with GSAP.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![preview img](/preview.png)
